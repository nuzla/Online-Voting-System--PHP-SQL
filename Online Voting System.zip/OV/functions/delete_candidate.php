<?php


	require 'connect.php';
	$result = array();

		$sql = "DELETE FROM `candidates` WHERE c_id = " . $_POST['c_id'];
		mysql_query("DELETE FROM votes WHERE voted_candidate = '" . md5($_POST['c_id']) . "'");
		$run = mysql_query($sql);

		if ($run) {
			$result['error'] = false;
			$result['message'] = "Deleted Successfully";
		}else{
			$result['error'] = true;
			$result['message'] = "Cannot be Deleted";
			//$result['message'] = mysql_error();
		}

		echo json_encode($result);
	

?>