<?php
session_start();
if(isset($_SESSION['voters_id'])){
session_destroy();
header ("Location:../");}
?>