<?php 
session_start();
	
	include 'connect.php';

	extract($_POST);

	$username = mysql_real_escape_string($_POST['username']);
    $password = mysql_real_escape_string($_POST['password']);

    $query = "SELECT * FROM admin";
    $result = mysql_query($query) or die ("Verification error");
    $array = mysql_fetch_array($result);
    
    if ($array['username'] == $username && $array['password'] == $password){
        $_SESSION['username'] = $username;
        $_SESSION['id'] = $array['id'];
        header("Location: ../admin/main");
    }
    
    else{
    	echo '<script language="javascript">';
        echo 'alert("Incorrecet username or password")';
        echo '</script>';
        echo '<meta http-equiv="refresh" content="0;url=../admin" />';
    }
?>