<?php

	include 'connect.php';

	$new_date = $_POST['new_date'];

	$query = mysql_query("UPDATE `elec_schedule` SET `schedule` = '$new_date' WHERE sched_id = 1");

	if ($query) {
		echo "<script>alert('UPDATED SUCCESSFULLY');</script>";
		echo "<meta http-equiv=refresh content='0;URL=../admin/main/?action=4' />";
	}

	else{
		echo mysql_error();
	}

?>