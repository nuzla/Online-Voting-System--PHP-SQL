<?php


	require 'connect.php';
	$result = array();

		$sql = "DELETE FROM voters WHERE voters_id = " . $_POST['voters_id'];
		$run = mysql_query($sql);

		if ($run) {
			$result['error'] = false;
			$result['message'] = "Deleted Successfully";
		}else{
			$result['error'] = true;
			$result['message'] = "Cannot be Deleted";
			//$result['message'] = mysql_error();
		}

		echo json_encode($result);
	

?>