<?php
session_start();
  if (isset($_SESSION['voters_id'])) {
    header('Location:pages/main');
  }
?>
<!DOCTYPE html>
<html>

	<head>

		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css.map">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css.map">
		<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">

		<script type="text/javascript" src="js/bootstrap.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		
	</head>
	<body>

		<div class="">
		
		<div class="panel panel-primary center" style="width:500px;margin:150px auto 0 auto;">
			<div class="panel-heading"><h4>Bacolod City Local Elections</h4></div>
			<div class="panel-body">

				<form style="width:50%; margin:0 auto; text-align:center;" method="post" class="center" action="functions/login.php">
					<table>
						<tr>
							<td colspan="2" align="center" id="result">&nbsp;</td>
						</tr>
						<tr>
							<td>Voter's ID:</td>
							<td><input class="form-control" type="text" name="voters_id" id="password" data-options="required:true"></input></td>
						</tr>
						<tr><td>&nbsp;</td></tr>
						<tr>
							<td></td>
							<td colspan="2" align="center"><input type="submit" href="javascript:void(0);"  class="btn btn-primary" id="submitbutton" style="width:80%;" value="Submit"></td>
						</tr>
					</table>
				</form>
			</div>
		</div>

		</div>

	</body>

</html>
