<div class='container_allen sched'>
	Set Election schedule <br>
	<form method="POST" action="../../functions/update_sched.php">
		<div class="input-group" style="width:300px;">
			<input class="form-control" name="new_date" type="date">
			<span class="input-group-btn">
				<input type="submit" class="btn btn-default">
			</span>
		</div>
	</form>

	<?php
		$sql = mysql_query("SELECT * FROM elec_schedule WHERE sched_id = 1");
		$res = mysql_fetch_array($sql);

		$d = explode("-", $res['schedule'] );

		switch ($d['1']) {
			case 1: $month = "January"; break;
			case 2: $month = "February"; break;
			case 3: $month = "March"; break;
			case 4: $month = "April"; break;
			case 5: $month = "May"; break;
			case 6: $month = "June"; break;
			case 7: $month = "July"; break;
			case 8: $month = "August"; break;
			case 9: $month = "September"; break;
			case 10: $month = "October"; break;
			case 11: $month = "November"; break;
			case 12: $month = "December"; break;
		}

	$new_format = $month . " " . $d[2] . ", " . $d[0];

		echo "<br>Current Election schedule: " . $new_format;
	?>

</div>