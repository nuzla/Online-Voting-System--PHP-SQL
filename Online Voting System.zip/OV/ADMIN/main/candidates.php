<script>

  function delete_candidate(id){
  var y = confirm("Are you sure you want to delete?");

    if(y == true){
      $.post('../../functions/delete_candidate.php',
        {

          c_id:id

        },function(e){

          var result  = eval('('+e+')');
          window.location.href = window.location.href;

        });
      }
    }

</script>

<script>
  $(document).ready(function(){

    $('.edit_button_candidates').each(function(index, element) {
      $(this).click(function(){

        $('.show_this_form_candidates').hide();
        $('.show_this_form_candidates').eq(index).show();
        $('.hide_this_form_candidates').show();
        $('.hide_this_form_candidates').eq(index).hide();

      });
    });

  });
</script>

            

<div class='container_allen candidates'>
		
		<div class="panel panel-primary" style="width:1024px; margin:0 auto;">

      <div class="panel-heading">

        <table width="100%;">
          <tr>

            <td width="50%;">
              <form method="POST">
                <div class="input-group" style="width: 100%">
                  <input type="text" class="form-control" name="find">
                  <span class="input-group-btn">
                    <button type="submit" class="btn btn-default">SEARCH</button>
                  </span>
                </div>
              </form>
            </td>

            <td width="50%;">
              <form method="POST">
                <select name="sort" class="form-control" style="width:30%; float:right" onchange="this.form.submit()">
                  <option><?php if (isset($_POST['sort'])) { echo $_POST['sort']; }else{echo "ORDER BY";} ?></option>
                  <option disabled></option>
                  <option value="firstname">First name</option>
                  <option value="lastname">Last name</option>
                  <option value="position">Position</option>
                  <option value="partylist">Partylist</option>
                </select>
              </form>
            </td>

          </tr>
        </table>

      </div>
    
        <div class="panel-body">

            <?php

              if (isset($_POST['find'])) {
                
                $find = mysql_query("SELECT * FROM candidates WHERE firstname like '%" . $_POST['find'] . "%' OR 
                                                                    lastname like '%" . $_POST['find'] . "%' OR
                                                                    position like '%" . $_POST['find'] . "%' OR
                                                                    partylist like '%" . $_POST['find'] . "%'");

                if ($find) {

                  echo "<table class='table' style='text-align: center; width: 100%; box-shadow: 0 0 5px #111'>";

                  echo "<thead>
                          <tr>
                            <th colspan=6><h4>SEARCH RESULTS</h4></th>
                          </tr>
                          <tr role='row'>
                            <th style='cursor:pointer; text-align: center; width: 15%;'><a>First name</a></th>
                            <th style='cursor:pointer; text-align: center; width: 15%;'><a>Last name</a></th>
                            <th style='cursor:pointer; text-align: center; width: 15%;'><a>Position</a></th>
                            <th style='cursor:pointer; text-align: center; width: 20%;'><a>Party list</a></th>
                            <th style='cursor:pointer; text-align: center; width: 20%;'><a>Candidate's Image</a></th>
                            <th style='cursor:pointer; text-align: center; width: 15%;'><a>Action</a></th>
                          </tr>
                        </thead>  ";

                  echo "<tbody>";

                  while ($array = mysql_fetch_array($find)) {
                  
                    echo " <tr class='hide_this_form_candidates'>
                            <td class=' sorting_1'>" . $array['firstname'] . "</td>
                            <td class=' sorting_1'>" . $array['lastname'] . "</td>
                            <td class=' sorting_1'>" . $array['position'] . "</td>
                            <td class=' sorting_1'>" . $array['partylist'] . "</td>
                            <td class=' sorting_1'>
                              <img style='height:50px; display:block; margin:0 auto; box-shadow: 0 0 5px #111; border-radius: 5px;' src='" . $array['c_image'] . "'>
                            </td>
                            <td class=' sorting_1'>
                                <button style='width:48%' class='edit_button_candidates btn btn-sm btn-default'>Edit</button>
                                <button style='width:48%' class='btn btn-sm btn-danger' onclick=\"delete_candidate('" . $array['c_id'] . "');\">Delete</button>
                            </td>
                          </tr>";

                    echo " <tr class='show_this_form_candidates' style='display:none'>
                            <form method='POST'>
                              <input type='hidden' name='edit_c_id' value='" . $array['c_id'] . "'>
                              <td class=' sorting_1'>" . "<input name='edit_c_firstname' class='form-control input-sm' type='text' value='" . $array['firstname'] . "'>" . "</td>
                              <td class=' sorting_1'>" . "<input name='edit_c_lastname' class='form-control input-sm' type='text' value='" . $array['lastname'] . "'>" . "</td>
                              <td class=' sorting_1'>" . "<input name='edit_c_position' class='form-control input-sm' type='text' value='" . $array['position'] . "'>" . "</td>
                              <td class=' sorting_1'>" . "<input name='edit_c_partylist' class='form-control input-sm' type='text' value='" . $array['partylist'] . "'>" . "</td>
                              <td class=' sorting_1'>
                                <img style='height:50px; display:block; margin:0 auto; box-shadow: 0 0 5px #111; border-radius: 5px;' src='" . $array['c_image'] . "'>
                              </td>
                              <td class=' sorting_1'>
                                  <button type='submit' class='btn btn-block btn-sm btn-primary'>Save</button>
                              </td>
                            </form>
                          </tr>";

                  }//while

                  echo "</tbody>";

                  echo "</table>";

                  echo "<hr>";

                }else{

                  echo "<hr>No results found!<hr>";

                }//else

              }//if isset

            ?>

            <table id="" class="table" style="text-align: center; width: 100%">

              <thead>
                <tr role="row">
                  <th style="cursor:pointer; text-align: center; width: 15%;"><a>First name</a></th>
                  <th style="cursor:pointer; text-align: center; width: 15%;"><a>Last name</a></th>
                  <th style="cursor:pointer; text-align: center; width: 15%;"><a>Position</a></th>
                  <th style="cursor:pointer; text-align: center; width: 20%;"><a>Party list</a></th>
                  <th style="cursor:pointer; text-align: center; width: 20%;"><a>Candidate's Image</a></th>
                  <th style="cursor:pointer; text-align: center; width: 15%;"><a>Action</a></th>
                </tr>
              </thead>      

              <tbody role="alert" aria-live="polite" aria-relevant="all">

                <?php

                if (isset($_POST['sort'])) {
                  $sort = $_POST['sort'];
                }else{
                  $sort = 'lastname';
                }

                if (isset($_POST['year'])) {
                  $year = $_POST['year'];
                }else{
                  $year = date('Y');
                }

                  $sql = mysql_query("SELECT * FROM candidates WHERE year = $year ORDER BY $sort");

                  while ($row = mysql_fetch_array($sql)) {

                    $x = mysql_query("SELECT * FROM votes WHERE voted_candidate = '" . md5($row['c_id']) . "'");

                    if (mysql_num_rows($x) == 0)
                    {
                      $edit = "<button style='width:48%' class='edit_button_candidates btn btn-sm btn-default'>Edit</button>";
                      $delete = "<button style='width:48%' class='btn btn-sm btn-danger' onclick=\"delete_candidate('" . $row['c_id'] . "');\">Delete</button>";
                    }
                    else
                    {
                      $edit = "<button style='width:48%;' class='edit_button_candidates btn btn-sm btn-default' disabled>Edit</button>";
                      $delete = "<button style='width:48%' class='btn btn-sm btn-danger' onclick=\"delete_candidate('" . $row['c_id'] . "');\" disabled>Delete</button>";
                    }

                    echo " <tr class='hide_this_form_candidates'>
                            <td class=' sorting_1'>" . $row['firstname'] . "</td>
                            <td class=' sorting_1'>" . $row['lastname'] . "</td>
                            <td class=' sorting_1'>" . $row['position'] . "</td>
                            <td class=' sorting_1'>" . $row['partylist'] . "</td>
                            <td class=' sorting_1'>
                              <img style='height:50px; display:block; margin:0 auto; box-shadow: 0 0 5px #111; border-radius: 5px;' src='" . $row['c_image'] . "'>
                            </td>
                            <td class=' sorting_1'>
                                $edit
                                $delete
                            </td>
                          </tr>";

                    echo " <tr class='show_this_form_candidates' style='display:none'>
                            <form method='POST'>
                              <input type='hidden' name='edit_c_id' value='" . $row['c_id'] . "'>
                              <td class=' sorting_1'>" . "<input name='edit_c_firstname' class='form-control input-sm' type='text' value='" . $row['firstname'] . "'>" . "</td>
                              <td class=' sorting_1'>" . "<input name='edit_c_lastname' class='form-control input-sm' type='text' value='" . $row['lastname'] . "'>" . "</td>
                              <td class=' sorting_1'>" . "<input name='edit_c_position' class='form-control input-sm' type='text' value='" . $row['position'] . "'>" . "</td>
                              <td class=' sorting_1'>" . "<input name='edit_c_partylist' class='form-control input-sm' type='text' value='" . $row['partylist'] . "'>" . "</td>
                              <td class=' sorting_1'>
                                <img style='height:50px; display:block; margin:0 auto; box-shadow: 0 0 5px #111; border-radius: 5px;' src='" . $row['c_image'] . "'>
                              </td>
                              <td class=' sorting_1'>
                                  <button type='submit' class='btn btn-block btn-sm btn-primary'>Save</button>
                              </td>
                            </form>
                          </tr>";

                  }

                //////////////////////////////////////////////////////////////////////////////////////////////////////////////
                  if (isset($_POST['edit_c_id'])) {

                    $check = mysql_query("SELECT * FROM positions");

                    while ($row = mysql_fetch_array($check)) {

                      if ($_POST['edit_c_position'] == $row['position_name']) {

                        $execute = mysql_query("UPDATE `candidates` SET `firstname`= '" . $_POST['edit_c_firstname'] . "', 
                              `lastname`= '" . $_POST['edit_c_lastname'] . "', 
                              `position`= '" . $_POST['edit_c_position'] . "', 
                              `partylist`= '" . $_POST['edit_c_partylist'] . "' 
                              WHERE c_id = " . $_POST['edit_c_id']);

                        if ($execute) { 
                          echo "<meta http-equiv=refresh content=0 />"; 
                        }// if query

                      }// if
 
                    }// while

                  }// if isset
                //////////////////////////////////////////////////////////////////////////////////////////////////////////////

                ?>

              </tbody>

            </table>  

        </div>

        <div class="panel-footer">
          <form method="POST" enctype="multipart/form-data" action="candidates_add.php">
            <table>
              <tr>
                <td><input class="form-control" type="text" name="firstname" placeholder="First name"></td>
                <td><input class="form-control" type="text" name="lastname" placeholder="Last name"></td>
                <td>
                  <select class="form-control" name="position">
                    <option>--Position--</option>

                    <?php

                      $sql = "SELECT * FROM positions";

                      $run = mysql_query($sql);

                      while ($row = mysql_fetch_array($run)) {

                        echo "<option value='" . $row['position_name'] . "'>" . $row['position_name'] . "</option>";

                      }

                    ?>

                  </select>
                </td>
                <td><input class="form-control" type="text" name="partylist" placeholder="Party List"></td>
                <td><input class="form-control" type="file" name="c_image" required></td>
                <td><input class="btn btn-primary" name="add_c_btn" type="submit" value="Add"></td>
              </tr>
            </table>
          </form>
        </div>

      </div>

</div>