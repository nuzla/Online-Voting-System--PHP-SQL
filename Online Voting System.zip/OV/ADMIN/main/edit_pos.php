<script>
  $(document).ready(function(){

    $('.edit_button_position').each(function(index, element) {
      $(this).click(function(){

        $('.show_this_form_position').hide();
        $('.show_this_form_position').eq(index).show();
        $('.hide_this_form_position').show();
        $('.hide_this_form_position').eq(index).hide();

      });
    });

  });
</script>

<script>

  function delete_position(id){
  var y = confirm("Are you sure you want to delete?");

    if(y == true){
      $.post('../../functions/delete_position.php',
        {

          pos_id:id

        },function(e){

          var result  = eval('('+e+')');
          window.location.href = window.location.href;

        });
      }
    }

</script>

<div class='container_allen edit'>

	<div class="panel panel-primary" style="width:1024px; margin:0 auto;">

      <div class="panel-heading"><h5>Current Positions</h5></div>
    
        <div class="panel-body">
	
			<?php

				$sql = "SELECT * FROM positions";
				$run = mysql_query($sql);

				echo "<table class='table data-table dataTable'>";

				echo "<tr>
						
						<th width=50%>Position name</th>
						<th style='text-align:center !important;' width=25%>Slots</th>
						<th style='text-align:center !important;' width=25%>Action</th>

					</tr>";

				while ($row = mysql_fetch_array($run)) {
					
					extract($row);

					echo "<tr class='hide_this_form_position'>
							<td>" . $position_name . "</td>
							<td style='text-align:center !important;'>" . $num_of_c_to_be_voted . "</td>
							<td style='text-align:center !important;'>
								<div class='btn-group'>
									<button class='btn btn-default btn-xs edit_button_position'>Edit</button>
									<button onclick=\"delete_position('" . $pos_id . "');\" class='btn btn-danger btn-xs'>Delete</button>
								</div>
							</td>
						</tr>";

					echo "<tr style='display:none;' class='show_this_form_position'>
							<form method='POST'>
								<input type='hidden' value='" . $pos_id . "' name='edit_pos_id'>
								<input type='hidden' value='" . $position_name . "' name='edit_pos_name'>
								<td><input type='text' class='form-control' value='" . $position_name . "' name='new_pos_name'></td>
								<td style='text-align:center !important;'><input class='form-control' style='width:20%;margin:0 auto; text-align:center' type='text' value='" . $num_of_c_to_be_voted . "' name='new_pos_slot'></td>
								<td style='text-align:center !important;'>
									<button type='submit' class='btn btn-default btn-block btn-xs' style='width:30%; margin:0 auto;'>Save</button>								
								</td>
							</form>
						</tr>";

				}

				echo "</table>";

			?>

		</div>

		<div class="panel-footer">
            <form method="POST">
              <div class="input-group">
                <table>
                  <tr>
                    <td width="50%"><input type="text" class="form-control" name="pos_name" placeholder="Position name"></td>
                    <td width="50%"><input type="number" min="1" class="form-control" name="pos_slot" placeholder="Slots for this position"></td>
                    <td><button style="background: #357ebd; color: #fff;" id="add_pos_btn" name="add" type="submit" class="btn btn-default">ADD</button></td>
                  </tr>
                </table>
              </div>
            </form>
        </div>

		<?php

			if (isset($_POST['pos_name'])) {
				$sql = mysql_query("INSERT INTO positions(position_name, num_of_c_to_be_voted) VALUES('" . $_POST['pos_name'] . "', " . $_POST['pos_slot'] . ")");
				if ($sql) {
					echo "<meta http-equiv=refresh content=0 />";
				}

			}

			if (isset($_POST['new_pos_name'])) {
				extract($_POST);
				$sql = mysql_query("UPDATE positions SET position_name = '$new_pos_name', num_of_c_to_be_voted = $new_pos_slot WHERE pos_id = $edit_pos_id");
				if ($sql) {
					mysql_query("UPDATE candidates SET position = '$new_pos_name' WHERE position = '$edit_pos_name'");
					echo "<meta http-equiv=refresh content=0 />";
				}
			}

		?>

    </div>

</div>