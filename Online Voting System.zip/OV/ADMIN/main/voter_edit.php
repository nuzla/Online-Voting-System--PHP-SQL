<?php include '../../functions/connect.php'; ?>
<!DOCTYPE html>
<html>

	<head>

		<title></title>

	</head>

	<body>

		<?php
			$sql = mysql_query("SELECT * FROM voters WHERE voters_id = " . $_GET['v_id']);
			$row = mysql_fetch_array($sql);
		?> 

		<form method="POST">
			<table width=50%>
				<tr>
					<td><input style="width:100%;" type="text" name="edit_firstname" value="<?php echo $row['firstname']; ?>"></td>
				</tr>
				<tr>
					<td><input style="width:100%;" type="text" name="edit_lastname" value="<?php echo $row['lastname']; ?>"></td>
				</tr>
				<tr>
					<td><textarea style="width:100%; height:100px;" name="edit_address"><?php echo $row['address']; ?></textarea></td>
				</tr>
				<tr>
					<td><input type="submit"></td>
				</tr>
			</table>
		</form>

	</body>

</html>

<?php

	if (isset($_POST['edit_firstname'])) {

		extract($_POST);
		
		$sql = "UPDATE voters SET firstname = '$edit_firstname', lastname = '$edit_lastname', address = '$edit_address' WHERE voters_id = " . $_GET['v_id'];
		$run = mysql_query($sql);

		if ($run) {
			echo "<script>

					alert('UPDATED');

					javascript:window.close();

				</script>";
		}

	}

?>