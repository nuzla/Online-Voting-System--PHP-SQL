<script>

  function delete_voter(id){
  var x = confirm("Are you sure you want to delete?");

    if(x == true){
      $.post('../../functions/delete_voter.php',
        {

          voters_id:id

        },function(e){

          var result  = eval('('+e+')');
          window.location.href = window.location.href;

        });
      }
    }

</script>

<div class='container_allen voters'>

    <div class="panel panel-primary" style="width:1024px; margin:0 auto;">

      <div class="panel-heading"><h5>List of Voters</h5></div>
    
        <div class="panel-body">

            <table id="voters_tbl" class="table data-table dataTable">

              <thead>
                <tr role="row">
                  <th style="cursor:pointer;"><a>Firstname</a></th>
                  <th style="cursor:pointer;"><a>Lastname</a></th>
                  <th style="cursor:pointer;"><a>Address</a></th>
                  <th style="cursor:pointer;"><a>Voter's ID</a></th>
                  <th style="cursor:pointer;"><a>Voted?</a></th>
                  <th style="cursor:pointer; width:100px"><a>Options</a></th>
                </tr>
              </thead>      

              <tbody role="alert" aria-live="polite" aria-relevant="all">

                <?php

                  $sql = mysql_query("SELECT * FROM voters ORDER BY done_voting");

                  while ($row = mysql_fetch_array($sql)) {

                    $edit = "<a href='voter_edit.php?v_id=" . $row['voters_id'] . "' target='_blank' class='btn btn-xs btn-default'>edit</a>";
                    $delete = "<button type='button' class='btn btn-xs btn-danger' onclick=\"delete_voter('" . $row['voters_id'] ."');\">Delete</button>";

                    if ($row['done_voting'] == 1) {
                      $done = "<img style='width:20px; display:block; margin:0 auto;' src='../../images/done.png'>";
                    }

                    else{
                      $done = "<img style='width:20px; display:block; margin:0 auto;' src='../../images/not_done.png'>";
                    }

                    echo " <tr>
                            <td class=' sorting_1'>" . $row['firstname'] . "</td>
                            <td class=' sorting_1'>" . $row['lastname'] . "</td>
                            <td class=' sorting_1'>" . $row['address'] . "</td>
                            <td class=' sorting_1'>" . $row['voters_id'] . "</td>
                            <td class=' sorting_1'>" . $done . "</td>
                            <td style='text-align:center; width:100px;'><div class='btn-group'>" . $edit . $delete . "</div></td>
                          </tr>";
                  }

                ?>

              </tbody>

            </table>  

          </div>

          <div class="panel-footer">

            <form method="POST" action="voter_add.php">
              <div class="input-group">
                <table>
                  <tr>
                    <td width="25%"><input type="text" class="form-control" name="firstname" placeholder="First name" required></td>
                    <td width="25%"><input type="text" class="form-control" name="lastname" placeholder="Last name" required></td>
                    <td width="50%"><input type="text" class="form-control" name="address" placeholder="Address" required></td>
                    <td><button style="background: #357ebd; color: #fff;" id="add_voter_btn" name="add" type="submit" class="btn btn-default">ADD</button></td>
                  </tr>
                </table>
              </div>
            </form>
          </div>

        </div>

</div>

