<nav>
	<ul class="nav nav-tabs nav-justified">
	    <li class="nav-1 active"><a href="../main" style='cursor:pointer'>List of Voters</a></li>
	    <li class="nav-2"><a href="?action=1" style='cursor:pointer'>Candidates</a></li>
	    <li class="nav-3"><a href="?action=2" style='cursor:pointer'>Result</a></li>
	    <li class="nav-4"><a href="?action=3" style='cursor:pointer'>Edit positions</a></li>
	    <li class="nav-5"><a href="?action=4" style='cursor:pointer'>Election Schedule</a></li>
	    <li class="nav-6"><a href="?action=5" style='cursor:pointer'>Preview</a></li>
	    <li class="nav-7"><a href="../../functions/admin_logout.php">logout</a></li>
	</ul>
</nav>