<?php

  include '../../functions/connect.php';

  if(isset($_POST['add_c_btn'])){

    extract($_POST);
            
    $image =  base64_encode(file_get_contents($_FILES['c_image']['tmp_name']));
    $image_data = base64_decode($image);
    $image_string = "data:image/jpeg;base64,".base64_encode($image_data);

    $year = date('Y');

    if ($_POST['position'] != '--Position--') {
      
      $sql = "INSERT INTO candidates SET 

      firstname = '$firstname',
      lastname = '$lastname',
      position = '$position',
      partylist = '$partylist',
      year = $year,
      c_image = '$image_string'";
                
      $run = mysql_query($sql);
              
      if($run){
        echo '<meta http-equiv="refresh" content="0;url=../main" />';
      }else{
        echo mysql_error();
      }

    }

    else{
      echo "<script>alert('Please select position');</script>";
      echo '<meta http-equiv="refresh" content="0;url=../main/?action=1" />';
    }
    
  }

?>