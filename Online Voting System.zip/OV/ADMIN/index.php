<?php
session_start();
  if (isset($_SESSION['username'])) {
    header('Location:main');
  }
?>
<!DOCTYPE html>
<html>

	<head>

		<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.css.map">
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../css/bootstrap-theme.css">
		<link rel="stylesheet" type="text/css" href="../css/bootstrap-theme.css.map">
		<link rel="stylesheet" type="text/css" href="../css/bootstrap-theme.min.css">

		<script type="text/javascript" src="../js/bootstrap.js"></script>
		<script type="text/javascript" src="../js/bootstrap.min.js"></script>

		<style>
			.panel-primary>.panel-heading,
			.btn-primary{
		        background: #272822;
		    }

		    .panel-primary,
	      	.panel-primary>.panel-heading,
	      	.btn-primary{
	        	border-color: #272822;
	      	}
		</style>
		
	</head>
	<body>

		<div>
		
		<div class="panel panel-primary center" style="width:500px;margin:150px auto 0 auto;">
			<div class="panel-heading"><h4>Bacolod City Local Elections -- ADMIN</h4></div>
			<div class="panel-body">
				<form id="login-form" style="width:50%; margin:0 auto; text-align:center;" method="post" action="../functions/admin_login.php" class="center">
					<table>
							<tr>
							<td colspan="2" align="center" id="result">&nbsp;</td>
						</tr>
						<tr>
							<td>Username:</td>
							<td><input class="form-control" type="text" name="username" id="username" data-options="required:true"></input></td>
						</tr>
						<tr>
							<td>Password:</td>
							<td><input class="form-control" type="password" name="password" id="password" data-options="required:true"></input></td>
						</tr>
						<tr><td>&nbsp;</td></tr>
						<tr>
							<td></td>
							<td colspan="2" align="center"><input type="submit" href="javascript:void(0);"  class="btn btn-primary" id="submitbutton" style="width:80%;" value="Submit"></td>
						</tr>
					</table>
				</form>
			</div>
		</div>

		</div>

	</body>

</html>