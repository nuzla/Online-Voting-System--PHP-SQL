<?php 
	include '../../functions/connect.php';
	include '../../functions/session.php';
?>
<!DOCTYPE html>
<html>
	<head>
		
		<?php include '../../functions/head.php'; ?>

		<style>

			body{
				background: #ccc;
			}


			/* ----------------------------------------------------- */

			input[type="checkbox"]{
			    display: none;
			}
			input[type="checkbox"]+label{
				padding: 10px 0px;
				text-align: center;
			    width: 240px;
			    display: inline-block;
			    margin: 2px;
			    cursor: pointer;
			    -webkit-filter: grayscale(100%);
				-moz-filter: grayscale(100%);
				-ms-filter: grayscale(100%);
				-o-filter: grayscale(100%);
				filter: grayscale(100%);

			}
			input[type="checkbox"]:checked+label{
			   	color: blue;
			   	font-weight: bold;
			   	border-radius: 5px;
				-webkit-filter: grayscale(0%);
				-moz-filter: grayscale(0%);
				-ms-filter: grayscale(0%);
				-o-filter: grayscale(0%);
				background: green;
			}


			.c_img{
				border: 1px solid black;
				width: 200px;
				height: 250px;
				display: block;
				margin: 0 auto;
			}

			.sub{
				margin: 0 auto;
				display: block;
				width: 1024px !important;
				height: 50px !important;
				text-align: center !important;
			}

		</style>

	</head>
	<body>
	
		<div style='margin: 0 auto; width:auto;' class="center vertical">

			<div class="panel panel-primary" style="width:1024px; margin: 20px auto;">

				<div class="panel-heading"><h5><?php echo $firstname . " " . $lastname . ""; ?></h5></div>

				<div class="panel-body">
					<p>
						<b>TO VOTE:</b> click the image/picture of your selected candidate for each position. 
						<br>to undo a vote, click again the highlighted image
						<br>after you finish selecting, click the <button class="btn btn-primary">Sumbit your votes</button> button below.
						<br>Vote wisely.
					</p>

					<p>
						<b>SA PAGBOTO:</b> pinduta lang ang picture/litrato sang imo ginpili nga kandidato sa kada position. 
						<br>Pinduta liwat ang picture/litrato kung sala imo na tum-okan para madula ang boto sa ina nga kandidato
						<br>Pagkatapos mo pili, pinduta lang ang <button class="btn btn-primary">Sumbit your votes</button> button sa dalom.
						<br>Mgboto sang inchakto.
					</p>
				</div>
			</div>

			<form method="POST">
			
				<?php 

					$all_pos = mysql_query("SELECT * FROM positions");

					while($all_pos_row = mysql_fetch_array($all_pos)){

						echo "
						<div class='panel panel-primary' style='width:1024px; margin-left: auto; margin-right: auto;'>
							<div class='panel-heading'><h5>" . $all_pos_row['position_name'] . "</h5></div>
							<div class='panel-body'>";


									$cong = mysql_query("SELECT * FROM candidates WHERE position = '" . $all_pos_row['position_name'] . "'");

									while ($row = mysql_fetch_array($cong)) {

										$slot = mysql_query("SELECT * FROM positions WHERE position_name = '" . $row['position'] . "'");
										$slot_r = mysql_fetch_array($slot);

										echo "
											<script type='text/javascript'>

												var " . $row['position'] . "_count = 0

												function set_check_" . $slot_r['pos_id'] . "(obj, slot, pos){

													var maxChecks = slot

													if(obj.checked){
														" . $row['position'] . "_count = " . $row['position'] . "_count + 1
													}
													else{
														" . $row['position'] . "_count = " . $row['position'] . "_count - 1
													}
												
													if (" . $row['position'] . "_count > maxChecks){
														obj.checked = false
														" . $row['position'] . "_count = " . $row['position'] . "_count - 1
														alert('you may only choose up to ' + maxChecks + ' ' + pos + '(s)')
													}
												}

											</script>
										";

										echo "<input id='c" . $row['c_id'] . "' type='checkbox' onclick=\"set_check_" . $slot_r['pos_id'] . "(this, " . $slot_r['num_of_c_to_be_voted'] . ", '" . $row['position'] . "')\" name='" . $row['position'] . "[]' value='" . $row['c_id'] . "'>" . 

											"<label for='c" . $row['c_id'] . "'><img class='c_img' src='" . $row['c_image'] . "'><br>"   

											. $row['firstname'] . " " . $row['lastname'] . "</label>";

									}

							echo "
							</div>
						</div>";

					}

				?>
				
				<input type="submit" class="btn btn-primary sub" name="submit_vote_btn" value='Submit your vote'>

			</form>

			<?php

				if (isset($_POST['submit_vote_btn'])) {

					extract($_POST);

					function submit_vote($voters_id, $c_id){

						$sql = "INSERT INTO votes(voters_id, voted_candidate) VALUES($voters_id, '" . md5($c_id) . "')";
						$run = mysql_query($sql);

						if ($run) {
							$done = mysql_query("UPDATE voters SET done_voting = 1, date_voted = NOW() WHERE voters_id = $voters_id");
						}

					}

					$result = mysql_query("SELECT * FROM positions");

					while ($retval = mysql_fetch_array($result)) {
						
						if (isset($_POST[$retval['position_name']])) {

							foreach($_POST[$retval['position_name']] as $submit_retval['pos_id']){

								submit_vote($voters_id, $submit_retval['pos_id']);

							}

						}

					}

					if(isset($_SESSION['voters_id'])){
						session_destroy();
						echo '<script language="javascript">';
						echo 'alert("Your vote has been counted")';
						echo '</script>';
						echo "<meta http-equiv=refresh content=0 />";
					}

				}

			?>

		</div>
		
	</body>

	<footer>
		<a href="../../functions/logout.php">signout</a>
	</footer>

</html>