<!DOCTYPE html>
<html>

  <head>

    <title></title>

    <link rel="stylesheet" type="text/css" href="../css/bootsrap.css">
    <link rel="stylesheet" type="text/css" href="../css/main.css">

  </head>

  <body>

    <?php include '../functions/connect.php'; ?>

    <div class='result' style="background:#FFF; width: 80%; margin:0 auto;">
        
        <div class="panel panel-primary" style="width:1024px; margin:0 auto;">

          <div class="panel-heading" style="background:#fff"><h1>Result</h1></div>
        
            <div class="panel-body">

            <?php
              
              function display_candidate($p){

              if (isset($_POST['year'])) {
                $year = $_POST['year'];
              }
              else{
                $year = date('Y');
              }
               
               $sql = mysql_query("SELECT * FROM candidates WHERE position = '$p' AND year = $year");
               $count_voters = mysql_query("SELECT count(*) as total_voters FROM voters WHERE done_voting = 1");
               $count_total_voters = mysql_fetch_assoc($count_voters);

                echo "  <table>
                            <tr>
                              <td><h3>" . $p . "</h3></td>
                              <td></td>
                            </tr>
                        ";

                while($row = mysql_fetch_array($sql)){

                  $a = md5($row['c_id']);
                 
                  $count = mysql_query("SELECT count(*) as total FROM votes WHERE voted_candidate = '$a'");
                  $count_result = mysql_fetch_assoc($count);

                  $percentage = round($count_result['total'] / $count_total_voters['total_voters'] * 100, 2) . "%";

                  echo "<tr>";
                  echo "<td width='200px;'>" . $row['firstname'] . " " . $row['lastname'] . "</td>";
                  echo "<td><meter style='width:500px;' min='0' max='" . $count_total_voters['total_voters'] . "' value='" . $count_result['total'] . "'></meter></td>";
                  echo "<td style='padding-left: 20px;'>" . $count_result['total'] . "</td>";
                  echo "<td style='padding-left: 20px;'>" . $percentage . "</td>";
                  echo "</tr>";

                }

                echo "  </table>";

              }

              $display = mysql_query("SELECT * FROM positions");

              while ($display_row = mysql_fetch_array($display)) {
                
                  display_candidate($display_row['position_name']);

              }
            
            ?>

          </div>

        </div>

    </div>

  </body>

</html>